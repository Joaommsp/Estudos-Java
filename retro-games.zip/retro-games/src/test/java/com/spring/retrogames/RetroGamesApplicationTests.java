package com.spring.retrogames;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetroGamesApplicationTests {

	@Test
	void contextLoads() {
	}

}
