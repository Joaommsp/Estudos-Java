package com.spring.retrogames;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RetroGamesApplication {

	public static void main(String[] args) {
		SpringApplication.run(RetroGamesApplication.class, args);
	}

}
